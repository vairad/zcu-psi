bin - obsahuje přeložený program pro Linux_x64 OS Debian s Qt 5
doc - osbahuje dokumentaci semestrální práce
src - obsahuje zdrojové soubory semestrální práce

